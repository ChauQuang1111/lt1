<!-- author: hgbaodev -->
# Đồ án môn lập trình web và ứng dụng
### Tài khoản Admin

- Username: hgbaodev
- Password: 123456
### Hình ảnh giao diện
![Alt text](./assets/img/screen.jpeg)
<h4 align="center">Trang chủ</h4>

![Alt text](./assets/img/img-github/admin-product.jpeg)
<h4 align="center">Chi tiết sản phẩm</h4>

![Alt text](./assets/img/img-github/giohang.jpeg)
<h4 align="center">Giỏ hàng</h4>

![Alt text](./assets/img/img-github/admin.jpeg)
<h4 align="center">Trang admin</h4>

![Alt text](./assets/img/img-github/admin-product.jpeg)
<h4 align="center">Quản lý sản phẩm</h4>
